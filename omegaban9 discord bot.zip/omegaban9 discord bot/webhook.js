const Discord = require('discord.js');

 
const hook = new Discord.WebhookClient('webhook id', 'webhook token');
{"type"; 1, 
"id"; "785754610463014973", 
"name"; "Captain Hook",
"avatar"; "0499bd99d83bb5d75821ac5e599242af", 
"channel_id"; "785266592325435435",
"guild_id"; "775526115577823233", 
"application_id"; null,
 "token"; "jyBHznDydhFDchX58FS-7nnE533bYgEaPL1UaMdFn5sxVfX6xgkBfc2QK_XpsaAUFTLs"
}
// Send a message using the webhook
hook.send('I am now alive!');